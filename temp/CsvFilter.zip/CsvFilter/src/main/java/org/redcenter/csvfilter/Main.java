package org.redcenter.csvfilter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;
import ch.qos.logback.core.util.StatusPrinter;

public class Main {
	private static final String PATH_CONFIG_LOGBACK = "./config/logback.xml";
	private static final String PATH_CONFIG = "./config/config.properties";
	private static final String PATH_INPUT_FOLDER = "./input/";
	private static final String FILE_EXT_CSV = ".csv";
	private static final String PATH_OUTPUT_CSV = "./output/output.csv";

	private static Logger LOGGER = LoggerFactory.getLogger(Main.class);

	public static void main(String[] args) throws Exception {
		LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
		context.reset();
		try {
			JoranConfigurator configurator = new JoranConfigurator();
			configurator.setContext(context);
			configurator.doConfigure(PATH_CONFIG_LOGBACK);
		} catch (JoranException je) {
			// StatusPrinter will handle this
		}
		StatusPrinter.printInCaseOfErrorsOrWarnings(context);

		try {
			// read config
			IpReader ipReader = new IpReader();
			Set<String> ips = ipReader.getIps();
			Properties prop = new Properties();
			try {
				FileInputStream inputStream = new FileInputStream(PATH_CONFIG);
				prop.load(inputStream);
			} catch (IOException e) {
				LOGGER.error(e.getMessage(), e);
			}
			int ipColumnIndex = Integer.parseInt(prop.getProperty("ipColumnIndex"));
			if (ipColumnIndex == -1) {
				LOGGER.error("No config ipColumnIndex found");
				return;
			}

			// read input
			File folder = new File(PATH_INPUT_FOLDER);
			FilenameFilter filter = new FilenameFilter() {
				public boolean accept(File dir, String name) {
					return name.toLowerCase().endsWith(FILE_EXT_CSV);
				}
			};

			// prepare output
			try (Writer writer = new BufferedWriter(
					new OutputStreamWriter(new FileOutputStream(PATH_OUTPUT_CSV), "utf-8"))) {
				// traverse file
				for (File file : folder.listFiles(filter)) {
					LOGGER.info("Filter " + file.getName());
					filterFile(writer, file, ipColumnIndex, ips);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		LOGGER.info("End");
	}

	private static void filterFile(Writer writer, File file, int ipColumnIndex, Set<String> ips)
			throws IOException, FileNotFoundException {
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			for (String line; (line = br.readLine()) != null;) {
				if (line.isEmpty()) {
					continue;
				}
				String ip = line.split(",")[ipColumnIndex];
				if (ips.contains(ip)) {
					writer.write(line + "\n");
				}
			}
		}
	}
}
