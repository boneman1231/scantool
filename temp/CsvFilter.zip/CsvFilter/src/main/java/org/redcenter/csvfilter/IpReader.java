package org.redcenter.csvfilter;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class IpReader {
	private static final String PATH = "./config/ip.txt";
	private Set<String> ips = new HashSet<String>();

	public IpReader() throws IOException {
		String contents = new String(Files.readAllBytes(Paths.get(PATH)));
		List<String> ipList = Arrays.asList(contents.split("\\s*\n\\s*"));
		ips = new HashSet<String>(ipList);
	}

	public Set<String> getIps() {
		return ips;
	}
}
